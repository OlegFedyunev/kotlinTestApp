import java.io.File

class Join(_joinType: String, _joinTable: String, _joinClause: String) {
    val joinType: String
    val joinTable: String
    val joinClause: String

    init {
        joinType = _joinType
        joinTable = _joinTable
        joinClause = _joinClause
    }

    internal fun printJoinInfo() {
        println("type: $joinType, table: $joinTable, clauses: $joinClause")
    }
}

class Sort(val sortType: String = "asc", val sortColumn: String) {

    internal fun printSortInfo() {
        println("type: $sortType, column: $sortColumn")
    }
}

class WhereClause(val clauseType: String, val clauseText: String) {

    internal fun printWhereClauseInfo() {
        println("clauseType: $clauseType, clauseText: $clauseText")
    }
}

class Query(query: String) {
    private var columns = mutableListOf<String>()
    private val fromSources = mutableListOf<String>()
    private var whereClauses = mutableListOf<WhereClause>()
    private var groupByColumns = mutableListOf<String>()
    private var sortColumns = mutableListOf<Sort>()
    private var joins = mutableListOf<Join>()
    private var limit: Int? = null
    private var offset: Int? = null

    init {

        val queryLines: List<String> = query.lines()
        queryLines.forEachIndexed { ind, line ->
            if (line.toString().lastIndexOf("SELECT ") >= 0) {
                columns = line.toString().replace("SELECT ", "").split(",").toMutableList()
            }
            else if (line.toString().lastIndexOf("FROM ") >= 0) {
                val fromSourcesBuf = line.toString().replace("FROM ", "").split(",")
                //if (fromSourcesBuf.isEmpty()) fromSources.add(line.toString().removePrefix("FROM "))
                //else {
                    for(item in fromSourcesBuf) {
                        fromSources.add(item)
                    }
                //}
            }
            else if (line.toString().lastIndexOf("WHERE ") >= 0) {
                val whereClausesBuf = line.toString().replace("WHERE ", "")
                whereClauses.add(WhereClause("where", whereClausesBuf))
            }
            else if (line.toString().lastIndexOf("HAVING ") >= 0) {
                val whereClausesBuf = line.toString().replace("HAVING ", "")
                whereClauses.add(WhereClause("having", whereClausesBuf))
            }
            else if (line.toString().lastIndexOf("GROUP BY ") >= 0) {
                groupByColumns = line.toString().replace("GROUP BY ", "").split(",").toMutableList()
            }
            else if (line.toString().lastIndexOf("INNER JOIN ") >= 0) {
                val index = line.toString().lastIndexOf("INNER JOIN ")
                val substrJoinTable = line.toString().substring(index).substringBefore("ON ").removePrefix("INNER JOIN ")
                val substrJoinClause = line.toString().substring(index).substringAfter("ON ")
                joins.add(Join("inner", substrJoinTable, substrJoinClause))
            }
            else if (line.toString().lastIndexOf("LEFT JOIN ") >= 0) {
                val index = line.toString().lastIndexOf("LEFT JOIN ")
                val substrJoinTable = line.toString().substring(index).substringBefore("ON ").removePrefix("LEFT JOIN ")
                val substrJoinClause = line.toString().substring(index).substringAfter("ON ")
                joins.add(Join("left", substrJoinTable, substrJoinClause))
            }
            else if (line.toString().lastIndexOf("RIGHT JOIN ") >= 0) {
                val index = line.toString().lastIndexOf("RIGHT JOIN ")
                val substrJoinTable = line.toString().substring(index).substringBefore("ON ").removePrefix("RIGHT JOIN ")
                val substrJoinClause = line.toString().substring(index).substringAfter("ON ")
                joins.add(Join("right", substrJoinTable, substrJoinClause))
            }
            else if (line.toString().lastIndexOf("FULL OUTER JOIN ") >= 0) {
                val index = line.toString().lastIndexOf("FULL OUTER JOIN ")
                val substrJoinTable = line.toString().substring(index).substringBefore("ON ").removePrefix("FULL OUTER JOIN ")
                val substrJoinClause = line.toString().substring(index).substringAfter("ON ")
                joins.add(Join("full outer", substrJoinTable, substrJoinClause))
            }
            else if (line.toString().lastIndexOf("ORDER BY ") >= 0) {
                val sortColumnsBuf = line.toString().replace("ORDER BY ", "").split(",")
                for (item in sortColumnsBuf) {
                    val indexDesc = item.toString().lastIndexOf(" DESC")
                    val indexAsc = item.toString().lastIndexOf(" ASC")
                    if (indexDesc >= 0) {
                        val substrSortColumn = item.toString().substringBefore(" DESC").removePrefix("ORDER BY ")
                        sortColumns.add(Sort("desc", substrSortColumn)) }
                    else if (indexAsc >= 0) {
                        val substrSortColumn = item.toString().substringBefore(" ASC").removePrefix("ORDER BY ")
                        sortColumns.add(Sort(sortColumn = substrSortColumn)) }
                    else sortColumns.add(Sort(sortColumn = item)) }
                }
            else if (line.toString().lastIndexOf("LIMIT ") >= 0) {
                limit = line.toString().substringAfter("LIMIT ").removeSuffix(";").trim().toInt()
            }
            else if (line.toString().lastIndexOf("OFFSET ") >= 0) {
                offset = line.toString().substringAfter("OFFSET ").removeSuffix(";").trim().toInt()
            }
            }

    }

    fun printQueryInfo() {
        println("columns")
        columns.forEach {
            println(it)
        }
        println("-------")

        println("fromSources")
        fromSources.forEach{
            println(it)
        }
        println("-------")

        println("whereClauses")
        whereClauses.forEach{
            it.printWhereClauseInfo()
        }
        println("-------")

        println("groupByColumns")
        for (item in groupByColumns) {
            println(item)
        }
        println("-------")

        println("joins")
        for (item in joins) {
            item.printJoinInfo()
        }
        println("-------")

        println("sortColumns")
        for (item in sortColumns) {
            item.printSortInfo()
        }
        println("-------")

        println("limit = $limit")
        println("-------")

        println("offset = $offset")
        println("-------")
    }
}

fun main(args: Array<String>) {
    var sqlQuery = File("querySelect.txt").readText(Charsets.UTF_8)
    sqlQuery = sqlQuery.toUpperCase()
    sqlQuery = sqlQuery.replace("\\s+".toRegex(), " ")
    sqlQuery = sqlQuery.replace("FROM ", "\n|FROM ")
    sqlQuery = sqlQuery.replace("INNER JOIN ", "\n|INNER JOIN ")
    sqlQuery = sqlQuery.replace("LEFT JOIN ", "\n|LEFT JOIN ")
    sqlQuery = sqlQuery.replace("RIGHT JOIN ", "\n|RIGHT JOIN ")
    sqlQuery = sqlQuery.replace("FULL OUTER JOIN ", "\n|FULL OUTER JOIN ")
    sqlQuery = sqlQuery.replace("WHERE ", "\n|WHERE ")
    sqlQuery = sqlQuery.replace("GROUP BY ", "\n|GROUP BY ")
    sqlQuery = sqlQuery.replace("ORDER BY ", "\n|ORDER BY ")
    sqlQuery = sqlQuery.replace("LIMIT ", "\n|LIMIT ")
    sqlQuery = sqlQuery.replace("OFFSET ", "\n|OFFSET ")
    sqlQuery = sqlQuery.trimMargin()
    var query = Query(sqlQuery)
    query.printQueryInfo()
}